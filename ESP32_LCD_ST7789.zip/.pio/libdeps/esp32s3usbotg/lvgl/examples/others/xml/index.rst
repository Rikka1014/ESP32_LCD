Load components at runtime
--------------------------

.. lv_example:: others/xml/lv_example_xml_1
  :language: c

.. lv_example:: others/xml/lv_example_xml_2
  :language: c
