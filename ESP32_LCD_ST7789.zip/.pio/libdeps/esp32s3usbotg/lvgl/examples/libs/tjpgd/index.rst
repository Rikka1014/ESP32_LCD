Load a JPG image
------------------

.. lv_example:: libs/tjpgd/lv_example_tjpgd_1
  :language: c

