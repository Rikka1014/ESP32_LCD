Load and render SVG data
---------------------------------------

.. lv_example:: libs/svg/lv_example_svg_1
  :language: c

